package com.kh.jpatotalapp.utils;

public class Common {
    // CORS 설정
    public final static String CORS_ORIGIN = "http://localhost:3000";
}
