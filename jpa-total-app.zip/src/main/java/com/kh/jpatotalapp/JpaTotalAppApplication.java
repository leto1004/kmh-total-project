package com.kh.jpatotalapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaTotalAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaTotalAppApplication.class, args);
	}

}
